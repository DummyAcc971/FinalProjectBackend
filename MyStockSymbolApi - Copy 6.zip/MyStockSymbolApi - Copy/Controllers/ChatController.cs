using Microsoft.AspNetCore.Mvc;
using MyStockSymbolApi.Services;
using MyStockSymbolApi.Models;
using System.Threading.Tasks;

[Route("api/chat")]
[ApiController]
public class ChatController : ControllerBase
{
    private readonly PerplexityService _perplexityService;

    public ChatController(PerplexityService perplexityService)
    {
        _perplexityService = perplexityService;
    }

    [HttpPost]
    public async Task<IActionResult> GetResponse([FromBody] ChatRequest request)
    {
        var response = await _perplexityService.GetPerplexityAnswer(request.Query);
        return Ok(new ChatResponse { Answer = response });
    }
}
