using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

public class PerplexityService
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey = "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";

    public PerplexityService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

   private bool IsStockRelated(string query)
{
    string[] stockKeywords = { "stock", "buy", "sell", "hold", "market", "shares", "investment", "trading" };
    return stockKeywords.Any(keyword => query.ToLower().Contains(keyword));
}

public async Task<string> GetPerplexityAnswer(string query)
{
    if (!IsStockRelated(query))
        return "I am a chatbot designed to help with stock-related inquiries.";

    string systemPrompt = "Answer briefly and to the point unless the user asks for more details. Answer within 5 lines. If the query is about buying or selling stocks, predict and provide guidance.";

    var requestContent = new
    {
        model = "sonar-pro",
        messages = new[]
        {
            new { role = "system", content = systemPrompt },
            new { role = "user", content = query }
        }
    };

    var jsonContent = JsonConvert.SerializeObject(requestContent);
    var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

    var request = new HttpRequestMessage(HttpMethod.Post, "https://api.perplexity.ai/chat/completions");
    request.Headers.Add("Authorization", $"Bearer {_apiKey}");
    request.Content = httpContent;

    var response = await _httpClient.SendAsync(request);
    var jsonResponse = await response.Content.ReadAsStringAsync();

    return ExtractAnswer(jsonResponse);
}

    private string ExtractAnswer(string jsonResponse)
    {
        try
        {
            var jsonObj = JObject.Parse(jsonResponse);
            return jsonObj["choices"]?[0]?["message"]?["content"]?.ToString() ?? "No answer found.";
        }
        catch
        {
            return "Error processing response.";
        }
    }
}
